let mongoose = require ('mongoose'),
  Schema = mongoose.Schema,

  IssueSchema = new Schema ({
    projectId: {
      type: mongoose.Schema.ObjectId,
      ref:'projects',
      trim:true,
    },
    comment: {
      required:[true, '{PATH} is required'],
      type: String, 
    },
    createdAt: {
      type: Date, 
      default: Date.now
    },

    updatedAt: {
      type: Date, 
      default: Date.now
    },
  });


  // save update time before update
  IssueSchema.pre('update', function(next) {
      this.set ('updatedAt', Date.now());
      return next();
  });



  module.exports = mongoose.model('issues', IssueSchema);

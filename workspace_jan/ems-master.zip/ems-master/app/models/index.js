module.exports = {
  user: require ('./user'),
  project: require ('./project'),
  issue: require ('./issue'),
  comment: require ('./comment'),
  forgotPassword: require ('./forgot-password')
}
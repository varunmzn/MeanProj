let mongoose = require('mongoose'),
  Schema = mongoose.Schema,

  commentSchema = new Schema({
    content: {
      type: String,
      required: true
    },
    // userId: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "users",
    //   required: true
    // },
     projectId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "projects",
      required: true
    },
    issueId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "issues",
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    },
  })

// save update time before update
commentSchema.pre('update', function (next) {
  this.set('updatedAt', Date.now());
  return next();
});


module.exports = mongoose.model('comments', commentSchema);
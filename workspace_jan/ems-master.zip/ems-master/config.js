module.exports =  {
    secret : "sample-ems",
    tokenExpireSeconds :84600,
    DB_USER: 'varun',        //root
    DB_PASSWORD: 'Varun@123',      //root
    DB_NAME: 'ticketing',
    // DB_URL: 'mongodb://ds149404.mlab.com:49404/ticketing', 
    DB_URL: 'mongodb://localhost:27017/ticketing',
         //mongodb://127.0.0.1:27017
    MAIL_USER: 'f1d8de36ebcb96',
    MAIL_PASSWORD: '379c9ecd3687e1',
    MAIL_HOST: 'smtp.mailtrap.io',
    MAIL_PORT: 465,
    MAIL_FROM: 'Varun Bhardwaj <varunkumar@virtualemployee.com>',
    HOST_NAME: 'http://192.168.6.234:3000'
}